<?php

$installer = $this;

$installer->deleteConfigData(Ebizmarts_MailChimp_Model_Config::ECOMMERCE_MC_JS_URL);

$installer->endSetup();
